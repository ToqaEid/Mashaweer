package com.jets.interfaces;

import com.jets.classes.Trip;

/**
 * Created by mohamed on 27/02/2017.
 */

public interface Communicator {

    public void sendMsg(Trip trip);

}
