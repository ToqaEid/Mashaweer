package com.jets.test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.jets.mashaweer.R;

public class test_notes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_notes);


    }
}
