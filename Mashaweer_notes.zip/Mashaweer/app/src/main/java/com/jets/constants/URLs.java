package com.jets.constants;

/**
 * Created by toqae on 13/03/2017.
 */

public class URLs {

    public static final String LOGIN_URL = "";
    public static final String REGISTER_URL = "";
}
